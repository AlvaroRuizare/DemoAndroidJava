package com.example.formulario.View;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.formulario.Data.DBHelper;
import com.example.formulario.R;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

public class Login extends AppCompatActivity {
    TextInputEditText tietUsuario, tietContrasena;
    DBHelper dbhelper;
    Snackbar snackbar;
    final ActivityResultLauncher<String> activityResultLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), new ActivityResultCallback<Boolean>() {
        @Override
        public void onActivityResult(Boolean o) {
            if (o){
                snackbar.setText("Permisos de notificación concedidos").show();
            } else {
                snackbar.setText("Permisos de notificación no concedidos").show();
            }
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        dbhelper = new DBHelper(this); // Se inicializa BD
        traerElementos(); // se hacen los findViewById

        // Se inicializa snackbar
        snackbar = Snackbar.make(
                findViewById(android.R.id.content),
                "",
                Snackbar.LENGTH_SHORT);
        snackbar.setBackgroundTint(ContextCompat.getColor(getApplicationContext(), R.color.md_theme_tertiary));
        snackbar.setActionTextColor(ContextCompat.getColor(getApplicationContext(), R.color.md_theme_onTertiary));

        // Pedir permisos de notificaciones
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && ActivityCompat.checkSelfPermission(
                Login.this,
                android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            activityResultLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS);
        }
    }


    /**
     * Trae todos los elementos del xml de login para poder trabajar con ellos
     */
    public void traerElementos() {
        tietUsuario = findViewById(R.id.tietUsuario); // TextInput usuario
        tietContrasena = findViewById(R.id.tietContrasena); // TextInput contraseña
    }


    /**
     * Al pulsar TextView 'Crear cuenta', navega a Registro
     */
    public void tvCrearCuenta(View view) {
        startActivity(new Intent(Login.this, Registro.class));
    }


    /**
     * Al pulsar botón 'Iniciar sesión', comprueba las credenciales
     */
    public void btnIniciarSesion(View view) {
        String valorCampoUsuario = String.valueOf(tietUsuario.getText());
        String valorCampoContrasena = String.valueOf(tietContrasena.getText());

        if (valorCampoUsuario.isBlank() || valorCampoContrasena.isBlank()){
            snackbar.setText("Los campos no pueden estar vacíos").show();
        }
        else if (dbhelper.estaDebaja(String.valueOf(tietUsuario.getText()))){
            snackbar.setText("El usuario está dado de baja").show();
        }
        else if(dbhelper.credencialesCorrectas(
                valorCampoUsuario,
                valorCampoContrasena)
        ) {
            Intent intent = new Intent(this, Listado.class);
            Bundle bundle = new Bundle(); // Se crea el bundle

            // Le pasamos el usuario al bundle
            bundle.putString("usuarioLogueado", String.valueOf(tietUsuario.getText()));

            intent.putExtras(bundle); // Le pasamos contenidos del bundle al intent
            startActivity(intent); // Pasamos a la siguiente página
        }
        else {
            snackbar.setText("Credenciales incorrectas").show();
        }
    }
}